Unzip the files, allowing the folders to be created that the zip file has encoded.

1.  Go to the ProgramCode folder and adjust any paths in the AdminDirector.ini, and Dev.DSN file to 
fit your machine.

2.  Register the two files in the SupportFiles folder.

3.  Login with a user name = 'user'  with no password.

4.  If you add users, add a folder with the same name under the Reports folder.

5.  See appendix A for dependent files.  You need Crystal 8.5, Microsoft Agent and all the other things
mentioned in the appendix.  If you don't have them you can hack away at the code until you have something
that works.

6.  Have fun with the code.  Sending any questions or problems to HerdingCats@mindspring.com